const Entry = require("./Entry.js");

let entry = new Entry({title: "Confused"});
