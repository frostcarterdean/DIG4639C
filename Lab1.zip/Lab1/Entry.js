class Entry {

  constructor(props) {
    this.props = props;
  }

  render() {
  }

}

module.exports = Entry;
